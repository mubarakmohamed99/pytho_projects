name=input("what is your name ?")
print(name)
color=input("what is your favorite colr?")
animal=input("what is your favroite animal? ")
# using the print()  with multiple variables to format a string
print("{}, you like a {} {}!".format(name,color,animal))