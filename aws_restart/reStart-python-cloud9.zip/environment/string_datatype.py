myString = " this is my my string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))