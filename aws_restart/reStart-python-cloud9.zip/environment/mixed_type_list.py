myMixwsTypeLiat= [45,290578, 1.02,True, "MY cat is on the bed .", "45"]
for item in myMixwsTypeLiat:
   print("{} is of the data type {}".format(item,type(item)))