userReply= input("do you need to ship a package? (enter yes or no)")
if userReply=="yes":
    print("we can help you ship that pakage !")
else:
    print("please come back when u need to ship that pakae .thnak you")
    