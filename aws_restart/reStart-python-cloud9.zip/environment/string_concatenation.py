firststring='water'
secondstring="fall"
thirdstring=firststring  +  secondstring
print(thirdstring)