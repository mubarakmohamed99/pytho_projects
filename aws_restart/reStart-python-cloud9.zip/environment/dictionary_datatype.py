myFavoriteFruitDictionary = {
    "Akua": "apple",
    "saanvi": "banana",
    "paulo": "pineapple"
    
            }

print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["saanvi"])
print(myFavoriteFruitDictionary["paulo"])