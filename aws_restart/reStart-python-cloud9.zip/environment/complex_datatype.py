myValue=5j
print(myValue)
print(type(myValue))
#combine numbers and text
print(str(myValue) + " is of the data type " + str(type(myValue)))
