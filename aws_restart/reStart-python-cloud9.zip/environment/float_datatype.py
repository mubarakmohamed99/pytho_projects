myValue=3.14
print(myValue)
print(type(myValue))
#combine numbers and text
print(str(myValue)  +  " is of the data type " + str(type(myValue)))

